#!c:\python\32-bit\2.7\python.exe

from cx_Freeze import main

main()

