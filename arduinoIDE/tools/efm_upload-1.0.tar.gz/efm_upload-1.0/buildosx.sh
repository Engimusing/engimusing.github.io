#!/bin/bash
cxfreeze ./efm_upload.py --target-dir=macosx